# Lab 3: Monitoring, Logging & DevSecOps
**Student Name:** Garvit Sharma  
**Roll No / Register No:** 2301730190  
**Email:** garvitsharma8909@gmail.com  
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 6: Implement Feature Flags and Perform Different Testing
**Marks:** 5 Marks

### Overview
This package contains the implementation of runtime feature toggles, automated Selenium end-to-end browser tests, and Locust load testing scenarios.

### Implemented Capabilities
1. **Dynamic Feature Flags:**
   Controlled by environment variable `FEATURE_GREETING_V2`.
   - When `false`: Home route outputs `"Welcome to the observable platform"` and metric gauge = 0.
   - When `true`: Home route outputs `"Welcome to the v2 observable platform"` and metric gauge = 1.
   Enables zero-downtime Canary releases and instant rollbacks without rebuilding containers.
2. **Automated Selenium E2E Tests (`tests/e2e/test_home.py`):**
   Uses pytest and headless Google Chrome webdriver to validate HTTP response content and feature flag rendering.
3. **Locust Workload Stress Testing (`tests/load/locustfile.py`):**
   Simulates concurrent user behavior hitting `/`, `/api/status`, and `/api/log-demo` with configurable wait times.

### Commands Executed
```bash
# 1. Run Selenium browser tests
pytest tests/e2e -v

# 2. Toggle Feature Flag to v2
$env:FEATURE_GREETING_V2='true'
docker compose up -d --build demo-app

# 3. Execute Headless Locust Load Test (10 users, 2 users/sec, 30s)
locust -f tests/load/locustfile.py --headless -u 10 -r 2 -t 30s --host http://localhost:8080
```

### Observations
- Selenium test passed: 2 passed in 1.48s.
- Locust load test generated 259 total requests at an average rate of 8.63 req/s with 0.00% failure rate.
- Median latency remained under 7.1ms, with 95% of all requests resolved within 16ms.
